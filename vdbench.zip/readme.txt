New owners (Oracle), new rules:
Vdbench has been moved to Oracle Technology Network (OTN)
http://www.oracle.com/technetwork/server-storage/vdbench-downloads-1901681.html
